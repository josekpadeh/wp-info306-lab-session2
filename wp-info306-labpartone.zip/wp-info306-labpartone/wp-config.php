<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_info306_lab_session2' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '[=tQ;;U=G~/xRqEyT&8k`d@&h/l]Xlx;;2=1Mitg6!ryept2Upg-~pn4I/C6yk;W' );
define( 'SECURE_AUTH_KEY',  's0O>F2E0NMEyVuVonDh0 yG^p.oy-f0QUc4]3k$d]oxOk<p@q75viXo2Udq,T$}E' );
define( 'LOGGED_IN_KEY',    'tL_]@,A:h&MWGx26=nX+~oz~N8y}[:ss?29L1T_ED=X[#ud*$`eoxw>Nobq7F@NH' );
define( 'NONCE_KEY',        '/oq_?CTaX(mkI@:nE(!+%MT|J(F*8:}JAtlyGtIt`eU`LkW?5(ih YB&(R<>8113' );
define( 'AUTH_SALT',        ',0aqn.%4u/{wbbs)F2T.b<sX+a$:R(P6]EGg5//:hn/P@`NL:}G**^.O{ nB~*RQ' );
define( 'SECURE_AUTH_SALT', 'MZ+|Ygb?Rw>deO/Z[w,$]>6LK^y+_WDC=#V[0?(G>nE8a.:(`ChYUF/7YA^_aqN5' );
define( 'LOGGED_IN_SALT',   'ANz$z& sx.zXHfO~aCsngt5h*gd.Xa&Gb::^:SBn[fM7npn=B8Dw*G=ZH*!/YF-w' );
define( 'NONCE_SALT',       ' VB>5H-v1X4,N|pvC5MGjq[esUr,h&N}gf9e{S.1|8.w1jCtij1WAdq&I<8jBN:V' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
